#!/bin/bash

echo "Stopping ITRasamRemoteSupport..."
sudo /bin/launchctl bootout system "/Library/LaunchDaemons/ITRasamRemoteSupport.plist" &> /dev/null || sudo /bin/launchctl unload "/Library/LaunchDaemons/ITRasamRemoteSupport.plist" &> /dev/null
sudo pkill -9 "ITRasamRemoteSupport" &> /dev/null || true
CONSOLE_USER=$(stat -f '%Su' /dev/console 2>/dev/null || true)
CONSOLE_UID=$(id -u "${CONSOLE_USER}" 2>/dev/null || true)
if [ -n "${CONSOLE_UID}" ] && [ "${CONSOLE_UID}" != "0" ]; then
    sudo /bin/launchctl bootout "gui/${CONSOLE_UID}" "/Library/LaunchAgents/ITRasamRemoteSupport-launchagent.plist" &> /dev/null || true
fi
sudo /bin/launchctl unload "/Library/LaunchDaemons/meshagentDiagnostic_periodicStart.plist" &> /dev/null
sudo /bin/launchctl unload "/Library/LaunchDaemons/meshagentDiagnostic.plist" &> /dev/null
sudo rm "/Library/LaunchDaemons/meshagentDiagnostic_periodicStart.plist" &> /dev/null
sudo rm "/Library/LaunchDaemons/meshagentDiagnostic.plist" &> /dev/null

echo "Resetting TCC permissions for ITRasamRemoteSupport..."
BUNDLE_ID=$(mdls -name kMDItemCFBundleIdentifier -raw "/usr/local/mesh_services/آی تی رسام/ITRasamRemoteSupport/ITRasamSupport" 2>/dev/null || true)
if [ -n "${BUNDLE_ID}" ] && [ "${BUNDLE_ID}" != "(null)" ]; then
    sudo tccutil reset All "${BUNDLE_ID}" &> /dev/null || true
fi
sudo tccutil reset All "ITRasamRemoteSupport" &> /dev/null || true

sudo rm "/usr/local/mesh_services/آی تی رسام/ITRasamRemoteSupport/ITRasamSupport" &> /dev/null
sudo rm "/usr/local/mesh_services/آی تی رسام/ITRasamRemoteSupport/ITRasamSupport.msh" &> /dev/null
sudo rm "/usr/local/mesh_services/آی تی رسام/ITRasamRemoteSupport/ITRasamSupport.db" &> /dev/null
sudo rm "/usr/local/mesh_services/meshagentDiagnostic/meshagentDiagnostic" &> /dev/null
sudo rm "/Library/LaunchDaemons/ITRasamRemoteSupport.plist" &> /dev/null
sudo rm "/Library/LaunchAgents/ITRasamRemoteSupport-launchagent.plist" &> /dev/null
echo "ITRasamRemoteSupport was uninstalled."
